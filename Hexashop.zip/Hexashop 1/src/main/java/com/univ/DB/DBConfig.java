package com.univ.DB;

public interface DBConfig {
String DRIVER="com.mysql.cj.jdbc.Driver";
String URL="jdbc:mysql://localhost:3306/SAIT";
String UNM="root";
String PW="root";
	
}
